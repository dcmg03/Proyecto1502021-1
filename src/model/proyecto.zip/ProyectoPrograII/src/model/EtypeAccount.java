package model;

public enum EtypeAccount {
	
    CURRENT, DEPOSIT;

}
