package model;

public interface ActionsAccount {
	
	public abstract void deposti(double residue);
	
	public abstract boolean retirement();
}
